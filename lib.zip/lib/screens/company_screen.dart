import 'package:flutter/material.dart';
import 'package:super_admin/models/company_model.dart';
import '../services/supabase_service.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  final SupabaseService _svc = SupabaseService();
  late Future<List<Company>> _futureCompanies;
  List<Company> _companies = [];

  @override
  void initState() {
    super.initState();
    _futureCompanies = _loadCompanies();
  }

  Future<List<Company>> _loadCompanies() async {
    final list = await _svc.fetchCompanies();
    _companies = list;
    return list;
  }

  Future<void> _toggleActive(Company company, bool newValue) async {
    final oldValue = company.isActive;

    // Optimistic UI update
    setState(() {
      company.isActive = newValue;
    });

    try {
      await _svc.updateIsActive(company.id, newValue);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '${company.companyName} set to ${newValue ? "active" : "inactive"}',
            ),
          ),
        );
      }
    } catch (e) {
      // Revert if failed
      setState(() {
        company.isActive = oldValue;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update ${company.companyName}: $e'),
          ),
        );
      }
    }
  }

  Future<void> _refresh() async {
    final list = await _svc.fetchCompanies();
    setState(() {
      _companies = list;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Companies — Super Admin'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
          ),
        ],
      ),
      body: FutureBuilder<List<Company>>(
        future: _futureCompanies,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final items = snapshot.data ?? _companies;
          if (items.isEmpty) {
            return const Center(child: Text('No companies found.'));
          }

          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final c = items[index];
                return ListTile(
                  title: Text(c.companyName),
                  subtitle: Text(c.companyNumber),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        c.isActive ? 'Active' : 'Inactive',
                        style: TextStyle(
                          color: c.isActive ? Colors.green : Colors.red,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Switch(
                        value: c.isActive,
                        onChanged: (val) => _toggleActive(c, val),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
