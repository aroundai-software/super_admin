import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:super_admin/screens/company_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 🧩 Initialize Supabase
  await Supabase.initialize(
    url: 'https://sjajaycmqwpqhepvqvzi.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNqYWpheWNtcXdwcWhlcHZxdnppIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI4Nzc5NzcsImV4cCI6MjA3ODQ1Mzk3N30.uFW5koljLypGF1f7xjE64muSHXOCnsshuYXD6PEfjlc',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Super Admin',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
      ),
      home: const CompaniesScreen(),
    );
  }
}
